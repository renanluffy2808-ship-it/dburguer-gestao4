# D’ Burger Gestão — Aplicativo Android Oficial (v2.6.0)

Aplicativo de gestão financeira e operacional completo para hamburguerias artesanais.
Versão Android nativa 100% autônoma e empacotada com o **mesmo código de alta fidelidade do Preview**:
- **Equivalência Visual Total**: Reproduz 1:1 o design, cores, tipografia e botões do Preview.
- **100% Autônomo e Offline**: O aplicativo roda diretamente com seus assets embutidos no APK (`assets/www/index.html`, `assets/app.js`, `assets/app.css`), sem depender de conexões instáveis para renderizar a interface.
- **Banco de Dados Local Persistente**: Produtos, adicionais, fluxo de caixa, pedidos e configurações ficam salvos na memória do celular.
- **Área Administrativa Completa**: Cardápio com fotos, adicionais, categorias e editor visual.
- **Cardápio Digital Público**: Acessível para clientes via link direto sem login obrigatório.
- **Operação Completa**: PDV, Insumos, Fichas Técnicas, Fluxo de Caixa nas 3 gavetas financeiras e Relatórios.

## 📱 Como Gerar e Instalar o Arquivo APK no Celular

### Opção 1: Pelo GitHub Actions (Sem Computador)
1. Crie um repositório no GitHub (ex: `dburguer-oficial`).
2. Envie os arquivos descompactados deste projeto para o repositório.
3. O GitHub Actions executará o fluxo de compilação automaticamente (leva cerca de 1 minuto).
4. Na aba **Actions**, toque na compilação concluída e baixe o artefato **dburger-gestao-apk-v2.6.0**.
5. **IMPORTANTE para evitar conflito:** Desinstale qualquer versão de teste anterior do aplicativo no seu celular (segure o ícone e toque em Desinstalar) antes de instalar o novo APK!
6. Toque no novo APK baixado e instale normalmente!

### Opção 2: Pelo Android Studio no Computador
1. Abra o Android Studio e selecione **Open**.
2. Abra a pasta deste projeto.
3. Aguarde a sincronização e clique em **Build** > **Build Bundle(s) / APK(s)** > **Build APK(s)**.
4. O APK estará disponível em `app/build/outputs/apk/debug/app-debug.apk`.
