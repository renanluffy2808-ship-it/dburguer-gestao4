# ProGuard rules for D' Burger Gestao
-keepattributes *Annotation*
-dontwarn br.com.dburger.gestao.**
