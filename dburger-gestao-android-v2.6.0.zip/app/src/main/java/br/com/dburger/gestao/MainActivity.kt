package br.com.dburger.gestao

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.webkit.WebViewAssetLoader

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView

    companion object {
        const val LOCAL_APP_URL = "https://appassets.androidplatform.net/assets/www/index.html"
        const val FALLBACK_FILE_URL = "file:///android_asset/www/index.html"
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Tema Dark nas barras de status e navegação do celular
        window.statusBarColor = Color.parseColor("#09090B")
        window.navigationBarColor = Color.parseColor("#18181B")

        // AssetLoader oficial do AndroidX para servir os assets web embutidos com segurança e sem restrição de CORS
        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView = WebView(this).apply {
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                allowFileAccess = true
                allowContentAccess = true
                allowFileAccessFromFileURLs = true
                allowUniversalAccessFromFileURLs = true

                // Configurações vitais para fidelidade mobile idêntica ao preview:
                // Desativa zoom de desktop para respeitar 1:1 o viewport mobile e densidade de tela
                useWideViewPort = false
                loadWithOverviewMode = false
                textZoom = 100 // Impede que o tamanho de fonte do sistema Android distorça o layout

                cacheMode = WebSettings.LOAD_DEFAULT
                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                mediaPlaybackRequiresUserGesture = false
                displayZoomControls = false
                builtInZoomControls = false
                setSupportZoom(false)
            }
            setBackgroundColor(Color.parseColor("#09090B"))
            scrollBarStyle = View.SCROLLBARS_INSIDE_OVERLAY
            isVerticalScrollBarEnabled = false

            webChromeClient = object : WebChromeClient() {
                override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
                    android.util.Log.d("DBurgerApp", "${consoleMessage?.message()} [linha ${consoleMessage?.lineNumber()}]")
                    return true
                }
            }

            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(
                    view: WebView,
                    request: WebResourceRequest
                ): WebResourceResponse? {
                    return assetLoader.shouldInterceptRequest(request.url)
                }

                override fun onReceivedError(
                    view: WebView,
                    request: WebResourceRequest,
                    error: WebResourceError
                ) {
                    super.onReceivedError(view, request, error)
                    if (request.isForMainFrame) {
                        view.post {
                            view.loadUrl(FALLBACK_FILE_URL)
                        }
                    }
                }
            }
        }

        setContentView(webView)

        // Trata o botão Voltar físico/gestual do celular para navegar nas abas e fechar modais
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        // Carrega a aplicação web 100% autônoma e offline embutida no próprio APK
        webView.loadUrl(LOCAL_APP_URL)
    }
}
